import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";

import * as schema from "./schema";

const url = process.env.DATABASE_URL;

if (!url) {
  throw new Error(
    "Falta DATABASE_URL. En local: postgres://conecta:conecta@localhost:5432/conecta. " +
      "En Railway: usa la referencia ${{Postgres.DATABASE_URL}} para viajar por la red privada.",
  );
}

/**
 * En desarrollo Next recarga los módulos en cada cambio; sin este singleton
 * cada recarga abriría un pool nuevo hasta agotar las conexiones de Postgres.
 */
const global_ = globalThis as unknown as { __conecta_sql?: ReturnType<typeof postgres> };

const sql =
  global_.__conecta_sql ??
  postgres(url, {
    max: Number(process.env.DATABASE_POOL_MAX ?? 5),
    ssl: process.env.DATABASE_SSL === "true" ? "require" : undefined,
    prepare: false,
  });

if (process.env.NODE_ENV !== "production") global_.__conecta_sql = sql;

export const db = drizzle(sql, { schema, casing: "snake_case" });
export { sql };
export type Db = typeof db;
